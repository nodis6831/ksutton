#include <stdio.h>
#include <string.h>


int main(){

    printf("%s\n", rotate("doghouse", 0));
    printf("%s\n", rotate("doghouse", 1));
    printf("%s\n", rotate("doghouse", 2));
    printf("%s\n", rotate("doghouse", 3));
    printf("%s\n", rotate("doghouse", 4));
    printf("%s\n", rotate("doghouse", 5));

    return 0;
}
