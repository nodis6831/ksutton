from sys import stdin

for s in stdin:
  print s.upper()
